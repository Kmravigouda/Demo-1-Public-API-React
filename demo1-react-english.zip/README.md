
# Demo — Public API (English only)

## Overview
This demo fetches posts from JSONPlaceholder and displays them in English. It does not rely on any external translation services.

## Setup
1. Install dependencies:
```bash
npm install
```

2. Start dev server:
```bash
npm run dev
```

3. Open the URL printed by Vite (usually http://localhost:5173/) or http://127.0.0.1:5173/

## Notes
- Fetches and displays the first 20 posts from https://jsonplaceholder.typicode.com/posts
- Includes loading and error states.
