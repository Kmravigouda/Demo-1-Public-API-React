import React from 'react'
import PostList from './components/PostList'

export default function App(){
  return (
    <div className="app">
      <header>
        <h1>Demo — Public API (English)</h1>
        <p>Fetches posts from JSONPlaceholder and displays them in English with loading & error states.</p>
      </header>
      <main>
        <PostList />
      </main>
    </div>
  )
}
