
import React, {useState, useEffect} from 'react'

export default function PostList(){
  const [posts, setPosts] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let cancelled = false
    async function fetchPosts(){
      setLoading(true)
      setError(null)
      try{
        const res = await fetch('https://jsonplaceholder.typicode.com/posts')
        if(!res.ok) throw new Error('Network response was not ok: ' + res.status)
        const data = await res.json()
        if(!cancelled) setPosts(data.slice(0, 20)) // show first 20
      }catch(err){
        if(!cancelled) setError(err.message)
      }finally{
        if(!cancelled) setLoading(false)
      }
    }
    fetchPosts()
    return () => { cancelled = true }
  }, [])

  if(loading) return <div className="state">Loading posts…</div>
  if(error) return <div className="state error">Error: {error}</div>
  if(!posts || posts.length === 0) return <div className="state">No posts found.</div>

  return (
    <div className="grid">
      {posts.map(post => (
        <article key={post.id} className="card">
          <h3>{post.title}</h3>
          <p>{post.body}</p>
        </article>
      ))}
    </div>
  )
}
